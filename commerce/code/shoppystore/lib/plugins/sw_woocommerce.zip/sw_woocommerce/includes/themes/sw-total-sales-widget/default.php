<?php	
	$top_sellers = $this->Get_TopSeller_Categories( $from_date, $to_date, $top_number, $tab_number );

	$widget_id = isset( $widget_id ) ? $widget_id : 'sw_topseller_'.rand().time();
if( $top_sellers > 0 ){
	$category = array();
	$top_qty  = array();
	foreach( $top_sellers as $key => $top ) {
		$category[$key] = $top->term_id;
		$top_qty[$key]	= $top->qty;
	}
	$column = 12/$columns;
	$column1 = 12/$columns1;
	$column2 = 12/$columns2;
	$column3 = 12/$columns3;
	
	$default = array(
		'post_type'	=> 'product',
		'tax_query'	=> array(
			array(
				'taxonomy'	=> 'product_cat',
				'field'		=> 'term_id',
				'terms'		=> implode(",", $category)
			)
		),
		'meta_query' => array(
			array(
				'key'     => 'total_sales',
				'value'   => $top_number,
				'compare' => '>='
			)
		),					
		'post_status' => 'publish',
		'orderby' => 'meta_value_num',
		'posts_per_page' => -1
	);
	$list = new WP_Query( $default );
	
	$total = $list->found_posts;
	
?>
<div id="<?php echo esc_attr( $widget_id ); ?>" class="sw-topseller-category <?php echo esc_attr( $numberposts ); ?>">
	<?php if( $title1 != '' ) : ?>
	<div class="order-title">
	     <span><?php echo $title1; ?></span>			
	</div>
	<div class="topseller-content clearfix">
		<ul class="nav nav-tabs">
			<li class="active">
				<a href="#<?php echo $widget_id.'_0'; ?>" data-toggle="tab"><?php echo __( 'All ', 'sw_woocommerce' ) .'('.  $total  . ')'; ?></a>
			</li>
		<?php 
			foreach( $category as $key => $cat ) { 
				$terms = get_term_by( 'id', $cat, 'product_cat' );
		?>
			<li>
				<a href="#<?php echo $widget_id.'_'.$cat; ?>" data-toggle="tab"><?php echo $terms->name .'('. $top_qty[$key] . ')' ; ?></a>
			</li>
		<?php } ?>
		</ul>
		<div class="tab-content">
		<?php 
				
				if( $list->have_posts() ){
		?>
				<div class="tab-pane active" id="<?php echo $widget_id.'_0'; ?>">
				<div class="row">
				<?php 
					while( $list->have_posts() ) : $list->the_post();
					global $post, $product;
				?>
					<div class="item pull-left col-lg-<?php echo $column ?>  col-md-<?php echo $column1 ?> col-sm-<?php echo $column2 ?> col-xs-<?php echo $column3 ?>">
						<div class="item-wrap">
							<div class="item-detail">										
								<div class="item-img products-thumb">											
									<!-- quickview & thumbnail  -->									
									<?php do_action( 'woocommerce_before_shop_loop_item_title' ); ?>
									<?php echo sw_quickview() ?>
								</div>										
								<div class="item-content">																			
									<!-- rating  -->
									<?php 
										$rating_count = $product->get_rating_count();
										$review_count = $product->get_review_count();
										$average      = $product->get_average_rating();
									?>
									<div class="reviews-content">
										<div class="star"><?php echo ( $average > 0 ) ?'<span style="width:'. ( $average*13 ).'px"></span>' : ''; ?></div>
										<div class="item-number-rating">
											<?php echo $review_count; _e(' Review(s)', 'sw_woocommerce');?>
										</div>
									</div>	
									<!-- end rating  -->
									<h4><a href="<?php the_permalink(); ?>" title="<?php the_title_attribute();?>"><?php the_title(); ?></a></h4>								

									<?php if ( $price_html = $product->get_price_html() ){?>
									<div class="item-price">
										<span>
											<?php echo $price_html; ?>
										</span>
									</div>
									<?php } ?>
									<!-- add to cart, wishlist, compare -->
									<div class="add-info">
									<?php do_action( 'woocommerce_after_shop_loop_item' ); ?>
									</div>
								</div>											
							</div>
						</div>
					</div>
					<?php endwhile; wp_reset_postdata(); ?>
				</div>
				</div>
				<?php } ?>

		<?php
			foreach( $category as $key => $cat ){
				$default = array(
					'post_type'	=> 'product',
					'tax_query'	=> array(
						array(
							'taxonomy'	=> 'product_cat',
							'field'		=> 'term_id',
							'terms'		=> $cat
						)
					),
					'meta_query' => array(
						array(
							'key'     => 'total_sales',
							'value'   => $top_number,
							'compare' => '>='
						)
					),					
					'post_status' => 'publish',
					'orderby' => 'meta_value_num',
					'showposts' => $top_qty[$key]
				);
				$list = new WP_Query( $default );
				
				if( $list->have_posts() ){
		?>
				<div class="tab-pane" id="<?php echo $widget_id.'_'.$cat; ?>">
				<div class="row">
				<?php 
					while( $list->have_posts() ) : $list->the_post();
					global $post, $product;
				?>
					<div class="item pull-left col-lg-<?php echo $column ?>  col-md-<?php echo $column1 ?> col-sm-<?php echo $column2 ?> col-xs-<?php echo $column3 ?>">
						<div class="item-wrap">
							<div class="item-detail">										
								<div class="item-img products-thumb">											
									<!-- quickview & thumbnail  -->									
									<?php do_action( 'woocommerce_before_shop_loop_item_title' ); ?>
									<?php echo sw_quickview() ?>
								</div>										
								<div class="item-content">																			
									<!-- rating  -->
									<?php 
										$rating_count = $product->get_rating_count();
										$review_count = $product->get_review_count();
										$average      = $product->get_average_rating();
									?>
									<div class="reviews-content">
										<div class="star"><?php echo ( $average > 0 ) ?'<span style="width:'. ( $average*13 ).'px"></span>' : ''; ?></div>
										<div class="item-number-rating">
											<?php echo $review_count; _e(' Review(s)', 'sw_woocommerce');?>
										</div>
									</div>	
									<!-- end rating  -->
									<h4><a href="<?php the_permalink(); ?>" title="<?php the_title_attribute();?>"><?php the_title(); ?></a></h4>								

									<?php if ( $price_html = $product->get_price_html() ){?>
									<div class="item-price">
										<span>
											<?php echo $price_html; ?>
										</span>
									</div>
									<?php } ?>
									<!-- add to cart, wishlist, compare -->
									<div class="add-info">
									<?php do_action( 'woocommerce_after_shop_loop_item' ); ?>
									</div>
								</div>											
							</div>
						</div>
					</div>
					<?php endwhile; wp_reset_postdata(); ?>
				</div>
				</div>
				<?php } ?>
			<?php } ?>
		</div>
	</div>
	<?php endif; ?>
</div>
<?php
}